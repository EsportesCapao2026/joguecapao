import Image from "next/image";
import Link from "next/link";
import {
  BadgeAlert,
  BarChart3,
  CalendarDays,
  ClipboardCheck,
  FileCog,
  Gavel,
  Goal,
  Home,
  ListChecks,
  LogOut,
  Settings,
  ShieldCheck,
  Trophy,
  Users,
} from "lucide-react";

const menu = [
  {
    label: "Início",
    href: "/admin/dashboard",
    icon: Home,
  },
  {
    label: "Campeonatos",
    href: "/admin/campeonatos",
    icon: Trophy,
  },
  {
    label: "Inscrições pendentes",
    href: "/admin/inscricoes",
    icon: ClipboardCheck,
  },
  {
    label: "Clubes e atletas",
    href: "/admin/clubes",
    icon: Users,
  },
  {
    label: "Jogos e rodadas",
    href: "/admin/jogos",
    icon: CalendarDays,
  },
  {
    label: "Resultados",
    href: "/admin/resultados",
    icon: BarChart3,
  },
  {
    label: "Artilheiros",
    href: "/admin/artilheiros",
    icon: Goal,
  },
  {
    label: "Denúncias",
    href: "/admin/denuncias",
    icon: BadgeAlert,
  },
  {
    label: "Pendências e punições",
    href: "/admin/punicoes",
    icon: Gavel,
  },
  {
    label: "Regras dos campeonatos",
    href: "/admin/regras",
    icon: ListChecks,
  },
  {
    label: "Configurações",
    href: "/admin/configuracoes",
    icon: Settings,
  },
];

export function AdminLayout({
  children,
  title,
  description,
}: {
  children: React.ReactNode;
  title: string;
  description: string;
}) {
  return (
    <main className="relative min-h-screen overflow-hidden bg-[#020806] text-white">
      <div
        className="fixed inset-0 z-0 bg-cover bg-center bg-no-repeat opacity-45"
        style={{ backgroundImage: "url('/bg-estadio.jpg')" }}
      />
      <div className="fixed inset-0 z-[1] bg-black/62" />
      <div className="fixed inset-0 z-[2] bg-[radial-gradient(circle_at_top_left,rgba(255,213,0,0.13),transparent_26%),radial-gradient(circle_at_top_right,rgba(0,195,255,0.15),transparent_30%),linear-gradient(to_bottom,rgba(0,0,0,0.10),rgba(0,0,0,0.75))]" />

      <div className="relative z-10 grid min-h-screen lg:grid-cols-[360px_1fr]">
        <aside className="border-r border-white/10 bg-black/52 p-5 shadow-2xl backdrop-blur-xl">
          <Link href="/" className="mb-7 block">
            <div className="relative h-24 w-[285px]">
              <Image
                src="/logo-capao.png"
                alt="Prefeitura de Capão da Canoa"
                fill
                priority
                className="object-contain object-left"
              />
            </div>
          </Link>

          <div className="mb-5 rounded-[26px] border border-white/10 bg-white/[0.045] p-4">
            <div className="mb-2 flex items-center gap-2 text-emerald-300">
              <ShieldCheck size={18} />
              <p className="text-xs font-black uppercase tracking-[0.22em]">
                Administração
              </p>
            </div>
            <h1 className="text-2xl font-black">Painel Jogue Capão</h1>
            <p className="mt-1 text-sm leading-6 text-white/50">
              Controle completo dos campeonatos municipais.
            </p>
          </div>

          <nav className="space-y-2">
            {menu.map((item, index) => {
              const Icon = item.icon;
              const isFirst = index === 0;

              return (
                <Link
                  href={item.href}
                  key={item.label}
                  className={`flex items-center gap-3 rounded-[22px] px-4 py-4 text-lg font-black transition hover:bg-white/[0.09] hover:text-emerald-300 ${
                    isFirst
                      ? "bg-gradient-to-r from-emerald-300/20 to-transparent text-emerald-300"
                      : "text-white/75"
                  }`}
                >
                  <Icon
                    size={22}
                    className={isFirst ? "text-emerald-300" : "text-white/65"}
                  />
                  <span>{item.label}</span>
                </Link>
              );
            })}
          </nav>

          <Link
            href="/admin/logout"
            className="mt-6 flex items-center gap-3 rounded-[22px] border border-white/10 bg-white/[0.05] px-4 py-4 text-lg font-black text-white/75 transition hover:bg-white/[0.09]"
          >
            <LogOut size={20} />
            Sair
          </Link>
        </aside>

        <section className="p-5 md:p-8">
          <header className="mb-6 rounded-[34px] border border-white/10 bg-black/42 p-6 shadow-2xl backdrop-blur-xl md:p-8">
            <p className="text-sm font-black uppercase tracking-[0.25em] text-emerald-300">
              Painel administrativo
            </p>
            <h2 className="mt-2 text-4xl font-black md:text-5xl">{title}</h2>
            <p className="mt-3 max-w-3xl text-lg leading-8 text-white/60">
              {description}
            </p>
          </header>

          {children}
        </section>
      </div>
    </main>
  );
}

export function AdminCard({
  title,
  value,
  description,
}: {
  title: string;
  value: string;
  description: string;
}) {
  return (
    <article className="rounded-[28px] border border-white/10 bg-black/42 p-6 shadow-2xl backdrop-blur-xl">
      <p className="text-sm font-black uppercase tracking-[0.18em] text-white/45">
        {title}
      </p>
      <p className="mt-3 bg-gradient-to-r from-[#ffd400] via-[#67dd7a] to-[#00bde7] bg-clip-text text-5xl font-black text-transparent">
        {value}
      </p>
      <p className="mt-2 text-sm leading-6 text-white/55">{description}</p>
    </article>
  );
}

export function AdminSection({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <section className="rounded-[34px] border border-white/10 bg-black/42 p-6 shadow-2xl backdrop-blur-xl md:p-8">
      <h3 className="text-3xl font-black">{title}</h3>
      <div className="mt-6">{children}</div>
    </section>
  );
}

export function AdminInput({
  label,
  placeholder,
}: {
  label: string;
  placeholder: string;
}) {
  return (
    <label className="block">
      <span className="mb-2 block text-sm font-black text-white/70">
        {label}
      </span>
      <input
        placeholder={placeholder}
        className="w-full rounded-2xl border border-white/12 bg-white/[0.06] px-4 py-4 font-bold text-white outline-none placeholder:text-white/28 focus:border-emerald-300"
      />
    </label>
  );
}

export function AdminSelect({
  label,
  options,
}: {
  label: string;
  options: string[];
}) {
  return (
    <label className="block">
      <span className="mb-2 block text-sm font-black text-white/70">
        {label}
      </span>
      <select className="w-full rounded-2xl border border-white/12 bg-white/[0.06] px-4 py-4 font-bold text-white outline-none focus:border-emerald-300">
        {options.map((option) => (
          <option key={option}>{option}</option>
        ))}
      </select>
    </label>
  );
}

export function AdminButton({ children }: { children: React.ReactNode }) {
  return (
    <button className="rounded-2xl bg-gradient-to-r from-[#ffd400] via-[#67dd7a] to-[#00bde7] px-6 py-4 font-black text-black transition hover:scale-[1.02]">
      {children}
    </button>
  );
}
