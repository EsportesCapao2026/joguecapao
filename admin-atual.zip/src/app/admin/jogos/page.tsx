
export default function AdminJogosPage() {
  return (
    
      <section className="space-y-6">
        <div className="grid gap-4 md:grid-cols-2">
          <Input label="Campeonato" placeholder="Municipal de Futsal" />
          <Input label="Categoria" placeholder="Masculino" />
          <Input label="Série" placeholder="Ouro" />
          <Input label="Rodada" placeholder="1" />
          <Input label="Equipe A" placeholder="Unidos" />
          <Input label="Equipe B" placeholder="Visual" />
          <Input label="Data" placeholder="dd/mm/aaaa" />
          <Input label="Horário" placeholder="19h" />
          <Input label="Local" placeholder="Ginásio Municipal" />
          <Input label="Link do mapa" placeholder="https://..." />
        </div>

        <button className="mt-5 rounded-2xl bg-gradient-to-r from-[#ffd400] via-[#67dd7a] to-[#00bde7] px-6 py-4 font-black text-black">
          Salvar jogo
        </button>
      </section>
    
  );
}

function Input({ label, placeholder }: { label: string; placeholder: string }) {
  return (
    <label className="block">
      <span className="mb-2 block text-sm font-black text-white/70">{label}</span>
      <input
        placeholder={placeholder}
        className="w-full rounded-2xl border border-white/12 bg-white/[0.06] px-4 py-4 font-bold text-white outline-none placeholder:text-white/28 focus:border-emerald-300"
      />
    </label>
  );
}
