import Image from "next/image";
import Link from "next/link";
import { supabasePublic } from "@/lib/supabasePublic";
import {
  ArrowRight,
  CalendarDays,
  Clock3,
  FileText,
  Gavel,
  ListChecks,
  MapPin,
  Medal,
  ShieldCheck,
  Table2,
  Trophy,
  Users,
} from "lucide-react";

const proximosJogos = [
  {
    rodada: "Rodada 1",
    categoria: "Masculino • Série Ouro",
    equipeA: "Unidos",
    equipeB: "Visual",
    data: "Sábado, 06/07",
    hora: "19h",
    local: "Ginásio Municipal",
  },
  {
    rodada: "Rodada 1",
    categoria: "Masculino • Série Prata",
    equipeA: "XT",
    equipeB: "Bom de Várzea",
    data: "Sábado, 06/07",
    hora: "20h",
    local: "Ginásio Municipal",
  },
  {
    rodada: "Rodada 2",
    categoria: "Feminino • Série Ouro",
    equipeA: "São Paulo",
    equipeB: "Vagal",
    data: "Domingo, 07/07",
    hora: "18h30",
    local: "Ginásio Municipal",
  },
];


const acessosRapidos = [
  {
    titulo: "Campeonatos",
    descricao: "Escolha um campeonato para ver jogos, classificação e artilharia.",
    href: "/campeonatos",
    icon: Trophy,
    destaque: true,
  },
  {
    titulo: "Jogos e confrontos",
    descricao: "Veja a agenda dos próximos jogos e rodadas.",
    href: "/campeonatos/municipal-futsal#jogos",
    icon: CalendarDays,
    destaque: false,
  },
  {
    titulo: "Inscrever equipe",
    descricao: "Cadastre time, atletas e responsável.",
    href: "/inscricoes",
    icon: Users,
    destaque: true,
  },
  {
    titulo: "Fazer denúncia",
    descricao: "Registre denúncia com partida, equipe e anexos.",
    href: "/denuncias",
    icon: FileText,
    destaque: false,
  },
  {
    titulo: "Regras do campeonato",
    descricao: "Consulte regulamentos e orientações oficiais.",
    href: "/regras",
    icon: ListChecks,
    destaque: false,
  },
  {
    titulo: "Punições",
    descricao: "Consulte atletas suspensos e decisões.",
    href: "/punicoes",
    icon: Gavel,
    destaque: false,
  },
  {
    titulo: "Classificação",
    descricao: "Disponível dentro de cada campeonato.",
    href: "/campeonatos",
    icon: Table2,
    destaque: false,
  },
  {
    titulo: "Artilheiros",
    descricao: "Ranking de gols por campeonato, categoria e série.",
    href: "/campeonatos",
    icon: Medal,
    destaque: false,
  },
  {
    titulo: "Painel administrativo",
    descricao: "Acesso restrito da organização.",
    href: "/admin",
    icon: ShieldCheck,
    destaque: true,
  },
];

export default async function Home() {
  const { data: campeonatosData } = await supabasePublic
    .from("campeonatos")
    .select("id, nome, modalidade, descricao, status, inscricoes_abertas, created_at")
    .neq("status", "encerrado")
    .order("created_at", { ascending: false })
    .limit(6);

  const campeonatos = (campeonatosData || []).map((campeonato) => ({
    nome: campeonato.nome,
    status:
      campeonato.inscricoes_abertas
        ? "Inscrições abertas"
        : campeonato.status === "pausado"
          ? "Pausado"
          : "Em andamento",
    descricao:
      campeonato.descricao ||
      `Campeonato municipal de ${campeonato.modalidade || "esportes"}.`,
    href: `/campeonatos/${campeonato.id}`,
  }));

  return (
    <main className="relative min-h-screen overflow-hidden bg-[#020806] text-white">
      <div
        className="fixed inset-0 z-0 bg-cover bg-center bg-no-repeat opacity-55"
        style={{ backgroundImage: "url('/bg-estadio.jpg')" }}
      />
      <div className="fixed inset-0 z-[1] bg-black/42" />
      <div className="fixed inset-0 z-[2] bg-[radial-gradient(circle_at_top_left,rgba(255,213,0,0.16),transparent_26%),radial-gradient(circle_at_top_right,rgba(0,195,255,0.18),transparent_30%),radial-gradient(circle_at_bottom_left,rgba(75,236,174,0.14),transparent_30%),linear-gradient(to_bottom,rgba(0,0,0,0.08),rgba(0,0,0,0.62))]" />
      <div className="fixed inset-0 z-[3] bg-[linear-gradient(rgba(90,255,210,0.035)_1px,transparent_1px),linear-gradient(90deg,rgba(90,255,210,0.035)_1px,transparent_1px)] bg-[size:64px_64px]" />

      <div className="relative z-10 mx-auto max-w-[1500px] px-4 py-6 md:px-8 md:py-8">
        <header className="rounded-[34px] border border-white/10 bg-black/38 px-5 py-5 shadow-2xl backdrop-blur-xl md:px-7">
          <div className="grid gap-5 xl:grid-cols-[260px_1fr] xl:items-center">
            <Link href="/" className="block shrink-0">
              <div className="relative h-20 w-[260px] sm:h-24 sm:w-[300px] xl:h-28 xl:w-[260px]">
                <Image
                  src="/logo-capao.png"
                  alt="Prefeitura de Capão da Canoa"
                  fill
                  priority
                  className="object-contain object-left"
                />
              </div>
            </Link>

            <nav className="flex flex-nowrap items-center justify-end gap-2 whitespace-nowrap">
              <a
                href="#campeonatos"
                className="rounded-2xl px-3 py-3 text-base font-extrabold text-white/85 transition hover:bg-white/10 hover:text-white xl:text-lg"
              >
                Campeonatos
              </a>

              <a
                href="#jogos"
                className="rounded-2xl px-3 py-3 text-base font-extrabold text-white/85 transition hover:bg-white/10 hover:text-white xl:text-lg"
              >
                Jogos
              </a>

              <Link
                href="/campeonatos"
                className="rounded-2xl px-3 py-3 text-base font-extrabold text-white/85 transition hover:bg-white/10 hover:text-white xl:text-lg"
              >
                Inscrições
              </Link>

              <Link
                href="/denuncias"
                className="rounded-2xl px-3 py-3 text-base font-extrabold text-white/85 transition hover:bg-white/10 hover:text-white xl:text-lg"
              >
                Denúncias
              </Link>

              <Link
                href="/regras"
                className="rounded-2xl px-3 py-3 text-base font-extrabold text-white/85 transition hover:bg-white/10 hover:text-white xl:text-lg"
              >
                Regras
              </Link>

              <Link
                href="/punicoes"
                className="rounded-2xl px-3 py-3 text-base font-extrabold text-white/85 transition hover:bg-white/10 hover:text-white xl:text-lg"
              >
                Punições
              </Link>

              <Link
                href="/admin"
                className="rounded-2xl bg-gradient-to-r from-[#ffd400] via-[#67dd7a] to-[#00bde7] px-5 py-3 text-base font-black text-black transition hover:scale-[1.02] xl:text-lg"
              >
                Área Admin
              </Link>
            </nav>
          </div>
        </header>

        <section className="grid gap-5 pt-5 lg:grid-cols-[1fr_360px]">
          <div className="rounded-[36px] border border-white/10 bg-black/36 p-6 shadow-2xl backdrop-blur-xl md:p-9">
            <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-emerald-300/20 bg-emerald-300/10 px-4 py-2 text-sm font-black text-emerald-200">
              <ShieldCheck size={16} />
              Sistema oficial de gestão esportiva
            </div>

            <h1 className="max-w-5xl text-3xl font-black leading-[1] tracking-tight sm:text-4xl md:text-5xl xl:text-6xl">
              <span className="text-white">Seja bem-vindo ao Sistema de</span>
              <br />
              <span className="bg-gradient-to-r from-[#ffd400] via-[#66db78] to-[#00bde7] bg-clip-text text-transparent">
                Campeonatos Municipais
              </span>
              <br />
              <span className="bg-gradient-to-r from-[#ffd400] via-[#66db78] to-[#00bde7] bg-clip-text text-transparent">
                de Capão da Canoa
              </span>
            </h1>

            <p className="mt-5 max-w-3xl text-base leading-7 text-white/70 md:text-lg">
              Plataforma oficial para facilitar a vida dos participantes e da organização:
              inscrições, próximos jogos, denúncias, regras, punições e informações
              dos campeonatos municipais em um só lugar.
            </p>

            <div className="mt-8 flex flex-wrap gap-3">
              <Link
                href="/campeonatos"
                className="inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-[#ffd400] via-[#67dd7a] to-[#00bde7] px-6 py-4 font-black text-black transition hover:scale-[1.02]"
              >
                Inscrever equipe
                <ArrowRight size={18} />
              </Link>

              <Link
                href="/denuncias"
                className="rounded-2xl border border-white/12 bg-white/[0.07] px-6 py-4 font-black text-white transition hover:bg-white/[0.12]"
              >
                Fazer denúncia
              </Link>

              <Link
                href="/regras"
                className="rounded-2xl border border-white/12 bg-white/[0.07] px-6 py-4 font-black text-white transition hover:bg-white/[0.12]"
              >
                Ver regras
              </Link>
            </div>

            <div className="mt-6 grid gap-3 sm:grid-cols-3">
              <InfoBox label="Campeonatos" value="Ativos" />
              <InfoBox label="Inscrições" value="Abertas" />
              <InfoBox label="Sistema" value="Profissional" />
            </div>
          </div>

          <aside className="rounded-[36px] border border-white/10 bg-black/42 p-5 shadow-2xl backdrop-blur-xl">
            <p className="text-sm font-black uppercase tracking-[0.25em] text-emerald-300">
              Acesso rápido
            </p>
            <h2 className="mt-2 text-3xl font-black">O que você precisa?</h2>
            <p className="mt-2 text-sm leading-6 text-white/55">
              Escolha uma opção para acessar diretamente a área desejada.
            </p>

            <div className="mt-5 space-y-3">
              {acessosRapidos.map((item) => {
                const Icon = item.icon;

                return (
                  <Link
                    href={item.href}
                    key={item.titulo}
                    className={`group flex items-center gap-4 rounded-[24px] border p-4 transition hover:-translate-y-1 ${
                      item.destaque
                        ? "border-emerald-300/20 bg-gradient-to-r from-[#ffd400]/15 via-[#67dd7a]/12 to-[#00bde7]/15"
                        : "border-white/10 bg-white/[0.055] hover:bg-white/[0.09]"
                    }`}
                  >
                    <div className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-emerald-300/12 text-emerald-300 transition group-hover:bg-emerald-300 group-hover:text-black">
                      <Icon size={23} />
                    </div>

                    <div>
                      <h3 className="font-black">{item.titulo}</h3>
                      <p className="mt-1 text-sm leading-5 text-white/55">
                        {item.descricao}
                      </p>
                    </div>
                  </Link>
                );
              })}
            </div>
          </aside>
        </section>

        <section id="jogos" className="grid gap-6 pt-8 pb-6 lg:grid-cols-[1.1fr_0.9fr]">
          <div className="rounded-[34px] border border-white/10 bg-black/40 p-6 shadow-2xl backdrop-blur-xl md:p-8">
            <p className="text-sm font-black uppercase tracking-[0.25em] text-emerald-300">
              Agenda esportiva
            </p>
            <div className="mt-2 flex items-center justify-between gap-4">
              <h2 className="text-3xl font-black md:text-5xl">Próximos jogos</h2>
              <div className="grid h-14 w-14 place-items-center rounded-2xl bg-emerald-300/10 text-emerald-300">
                <CalendarDays size={28} />
              </div>
            </div>

            <div className="mt-6 space-y-4">
              {proximosJogos.map((jogo) => (
                <article
                  key={`${jogo.equipeA}-${jogo.equipeB}`}
                  className="rounded-[28px] border border-white/10 bg-white/[0.055] p-5 transition hover:bg-white/[0.085]"
                >
                  <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
                    <span className="rounded-full bg-emerald-300/12 px-4 py-2 text-sm font-black text-emerald-200">
                      {jogo.rodada}
                    </span>
                    <span className="text-sm font-bold text-white/50">
                      {jogo.categoria}
                    </span>
                  </div>

                  <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-3">
                    <div className="text-left text-2xl font-black md:text-3xl">
                      {jogo.equipeA}
                    </div>

                    <div className="rounded-2xl border border-white/10 bg-black/35 px-4 py-2 text-lg font-black text-white/55">
                      X
                    </div>

                    <div className="text-right text-2xl font-black md:text-3xl">
                      {jogo.equipeB}
                    </div>
                  </div>

                  <div className="mt-5 grid gap-3 text-sm text-white/65 md:grid-cols-3">
                    <div className="flex items-center gap-2">
                      <CalendarDays size={16} className="text-emerald-300" />
                      {jogo.data}
                    </div>

                    <div className="flex items-center gap-2">
                      <Clock3 size={16} className="text-emerald-300" />
                      {jogo.hora}
                    </div>

                    <div className="flex items-center gap-2">
                      <MapPin size={16} className="text-emerald-300" />
                      {jogo.local}
                    </div>
                  </div>
                </article>
              ))}
            </div>
          </div>

          <div className="rounded-[30px] border border-white/10 bg-black/40 p-6 shadow-2xl backdrop-blur-xl">
            <p className="text-sm font-black uppercase tracking-[0.25em] text-emerald-300">
              Importante
            </p>
            <h3 className="mt-2 text-3xl font-black">
              Classificação e artilharia ficam dentro de cada campeonato.
            </h3>
            <p className="mt-4 text-base leading-7 text-white/68">
              Como o município pode ter vários campeonatos ao mesmo tempo, com categorias
              e séries diferentes, a tabela de classificação e a artilharia serão exibidas
              após o usuário escolher o campeonato desejado.
            </p>

            <a
              href="#campeonatos"
              className="mt-6 inline-flex items-center gap-2 rounded-2xl border border-white/12 bg-white/[0.06] px-6 py-4 font-black text-white transition hover:bg-white/[0.1]"
            >
              Escolher campeonato
              <ArrowRight size={18} />
            </a>
          </div>
        </section>

        <section id="campeonatos" className="pb-14 pt-2">
          <div className="mb-6">
            <p className="text-sm font-black uppercase tracking-[0.25em] text-emerald-300">
              Campeonatos
            </p>
            <h2 className="mt-2 text-3xl font-black md:text-5xl">
              Escolha o campeonato para ver detalhes.
            </h2>
          </div>

          <div className="grid gap-4 md:grid-cols-3">
            {campeonatos.map((campeonato) => (
              <article
                key={campeonato.nome}
                className="rounded-[28px] border border-white/10 bg-black/40 p-6 shadow-2xl backdrop-blur-xl transition hover:-translate-y-1 hover:bg-white/[0.07]"
              >
                <div className="mb-4 grid h-12 w-12 place-items-center rounded-2xl bg-emerald-300/12 text-emerald-300">
                  <Trophy size={24} />
                </div>

                <span className="rounded-full bg-emerald-300/12 px-3 py-1 text-xs font-black text-emerald-200">
                  {campeonato.status}
                </span>

                <h3 className="mt-4 text-2xl font-black">{campeonato.nome}</h3>
                <p className="mt-3 leading-7 text-white/60">{campeonato.descricao}</p>

                <Link href={campeonato.href} className="mt-5 inline-flex w-full items-center justify-center rounded-2xl bg-gradient-to-r from-[#ffd400] via-[#67dd7a] to-[#00bde7] px-5 py-4 font-black text-black transition hover:scale-[1.02]">
                  Ver campeonato
                </Link>
              </article>
            ))}
          </div>
        </section>
      </div>
    </main>
  );
}

function InfoBox({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-black/30 p-4">
      <p className="text-xs font-bold uppercase tracking-[0.18em] text-white/45">
        {label}
      </p>
      <p className="mt-1 bg-gradient-to-r from-[#ffd400] via-[#67dd7a] to-[#00bde7] bg-clip-text text-xl font-black text-transparent">
        {value}
      </p>
    </div>
  );
}
