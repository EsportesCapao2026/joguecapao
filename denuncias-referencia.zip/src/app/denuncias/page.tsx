import Image from "next/image";
import Link from "next/link";
import {
  ArrowLeft,
  BadgeAlert,
  CalendarDays,
  FileImage,
  FileText,
  ShieldCheck,
  Trophy,
  UserRound,
} from "lucide-react";

export default function DenunciasPage() {
  return (
    <main className="relative min-h-screen overflow-hidden bg-[#020806] text-white">
      <Background />

      <div className="relative z-10 mx-auto max-w-7xl px-4 py-6 md:px-8">
        <Header />

        <section className="grid gap-6 pt-8 lg:grid-cols-[0.85fr_1.15fr]">
          <aside className="rounded-[36px] border border-white/10 bg-black/42 p-6 shadow-2xl backdrop-blur-xl md:p-8">
            <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-emerald-300/20 bg-emerald-300/10 px-4 py-2 text-sm font-black text-emerald-200">
              <BadgeAlert size={16} />
              Denúncia pública
            </div>

            <h1 className="text-4xl font-black leading-tight md:text-6xl">
              Registre uma{" "}
              <span className="bg-gradient-to-r from-[#ffd400] via-[#67dd7a] to-[#00bde7] bg-clip-text text-transparent">
                denúncia oficial.
              </span>
            </h1>

            <p className="mt-5 text-lg leading-8 text-white/68">
              Informe campeonato, categoria, série, equipe denunciada, partida,
              atleta ou comissão envolvida e descreva o ocorrido. A denúncia será
              analisada pela organização.
            </p>

            <div className="mt-8 space-y-3">
              <Info icon={<Trophy size={22} />} title="Campeonato" text="Selecione a competição correta." />
              <Info icon={<CalendarDays size={22} />} title="Partida" text="Vincule a denúncia à rodada ou jogo." />
              <Info icon={<UserRound size={22} />} title="Alvo" text="Indique atleta, comissão ou denúncia geral." />
              <Info icon={<FileImage size={22} />} title="Anexos" text="Inclua imagens ou documentos de apoio." />
            </div>
          </aside>

          <section className="rounded-[36px] border border-white/10 bg-black/44 p-6 shadow-2xl backdrop-blur-xl md:p-8">
            <p className="text-sm font-black uppercase tracking-[0.25em] text-emerald-300">
              Formulário de denúncia
            </p>
            <h2 className="mt-2 text-3xl font-black md:text-4xl">
              Dados da denúncia
            </h2>

            <form className="mt-7 space-y-6">
              <div className="grid gap-4 md:grid-cols-2">
                <Campo label="Seu nome" placeholder="Nome completo" />
                <Campo label="WhatsApp" placeholder="(51) 99999-9999" />
                <Campo label="Clube que você representa" placeholder="Ex.: Unidos, XT..." />

                <Select label="Campeonato" options={["Selecione o campeonato", "Municipal de Futsal", "Municipal de Futebol"]} />
                <Select label="Categoria" options={["Selecione a categoria", "Masculino", "Feminino"]} />
                <Select label="Série" options={["Selecione a série", "Ouro", "Prata", "Bronze"]} />
                <Select label="Equipe denunciada" options={["Selecione a equipe", "Unidos", "Visual", "XT", "Bom de Várzea"]} />
                <Select label="Rodada / partida" options={["Selecione a partida", "Rodada 1 - Unidos x Visual", "Rodada 1 - XT x Bom de Várzea"]} />
                <Select label="O que deseja denunciar?" options={["Denúncia geral", "Atleta", "Comissão técnica", "Outro motivo"]} />
                <Select label="Atleta / membro envolvido" options={["Selecione se houver", "João Silva", "Pedro Santos", "Carlos Oliveira"]} />
              </div>

              <label className="block">
                <span className="mb-2 block text-sm font-black text-white/70">
                  Descrição da denúncia
                </span>
                <textarea
                  placeholder="Descreva de forma clara o que aconteceu..."
                  className="min-h-40 w-full rounded-2xl border border-white/12 bg-white/[0.06] px-4 py-4 font-bold text-white outline-none transition placeholder:text-white/28 focus:border-emerald-300"
                />
              </label>

              <div className="rounded-[28px] border border-dashed border-white/18 bg-white/[0.045] p-5">
                <div className="flex items-center gap-3">
                  <FileText className="text-emerald-300" size={24} />
                  <div>
                    <h3 className="font-black">Anexos da denúncia</h3>
                    <p className="text-sm text-white/55">
                      Área reservada para imagens ou documentos. A conexão com upload entra na próxima etapa.
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap gap-3">
                <button
                  type="button"
                  className="rounded-2xl bg-gradient-to-r from-[#ffd400] via-[#67dd7a] to-[#00bde7] px-6 py-4 font-black text-black transition hover:scale-[1.02]"
                >
                  Enviar denúncia
                </button>

                <Link
                  href="/"
                  className="rounded-2xl border border-white/12 bg-white/[0.06] px-6 py-4 font-black text-white transition hover:bg-white/[0.1]"
                >
                  Cancelar
                </Link>
              </div>
            </form>
          </section>
        </section>
      </div>
    </main>
  );
}

function Background() {
  return (
    <>
      <div className="fixed inset-0 z-0 bg-cover bg-center bg-no-repeat opacity-50" style={{ backgroundImage: "url('/bg-estadio.jpg')" }} />
      <div className="fixed inset-0 z-[1] bg-black/55" />
      <div className="fixed inset-0 z-[2] bg-[radial-gradient(circle_at_top_left,rgba(255,213,0,0.15),transparent_26%),radial-gradient(circle_at_top_right,rgba(0,195,255,0.16),transparent_30%),linear-gradient(to_bottom,rgba(0,0,0,0.12),rgba(0,0,0,0.72))]" />
      <div className="fixed inset-0 z-[3] bg-[linear-gradient(rgba(90,255,210,0.035)_1px,transparent_1px),linear-gradient(90deg,rgba(90,255,210,0.035)_1px,transparent_1px)] bg-[size:64px_64px]" />
    </>
  );
}

function Header() {
  return (
    <header className="rounded-[34px] border border-white/10 bg-black/42 px-5 py-5 shadow-2xl backdrop-blur-xl md:px-7">
      <div className="flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
        <Link href="/" className="block">
          <div className="relative h-24 w-[300px] sm:h-28 sm:w-[340px] xl:h-32 xl:w-[340px]">
            <Image src="/logo-capao.png" alt="Prefeitura de Capão da Canoa" fill priority className="object-contain object-left" />
          </div>
        </Link>

        <Link href="/" className="inline-flex w-fit items-center gap-2 rounded-2xl border border-white/12 bg-white/[0.06] px-5 py-3 font-black text-white transition hover:bg-white/[0.1]">
          <ArrowLeft size={18} />
          Voltar para início
        </Link>
      </div>
    </header>
  );
}

function Campo({ label, placeholder }: { label: string; placeholder: string }) {
  return (
    <label className="block">
      <span className="mb-2 block text-sm font-black text-white/70">{label}</span>
      <input
        placeholder={placeholder}
        className="w-full rounded-2xl border border-white/12 bg-white/[0.06] px-4 py-4 font-bold text-white outline-none transition placeholder:text-white/28 focus:border-emerald-300"
      />
    </label>
  );
}

function Select({ label, options }: { label: string; options: string[] }) {
  return (
    <label className="block">
      <span className="mb-2 block text-sm font-black text-white/70">{label}</span>
      <select className="w-full rounded-2xl border border-white/12 bg-white/[0.06] px-4 py-4 font-bold text-white outline-none transition focus:border-emerald-300">
        {options.map((item) => (
          <option key={item}>{item}</option>
        ))}
      </select>
    </label>
  );
}

function Info({ icon, title, text }: { icon: React.ReactNode; title: string; text: string }) {
  return (
    <div className="flex gap-4 rounded-[24px] border border-white/10 bg-white/[0.045] p-4">
      <div className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-emerald-300/12 text-emerald-300">
        {icon}
      </div>
      <div>
        <h3 className="font-black">{title}</h3>
        <p className="mt-1 text-sm leading-6 text-white/58">{text}</p>
      </div>
    </div>
  );
}
